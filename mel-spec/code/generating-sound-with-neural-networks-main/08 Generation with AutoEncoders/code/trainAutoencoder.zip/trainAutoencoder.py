from tensorflow.keras.datasets import mnist
import pickle as pickle
import numpy as np
from tensorflow.keras.callbacks import EarlyStopping

from autoencoder import Autoencoder


LEARNING_RATE = 0.0001
BATCH_SIZE = 4
EPOCHS = 80


def normalize_data(data):
    # Calculate mean and standard deviation along the first axis (usually the samples axis)
    mean = np.mean(data, axis=0)
    std = np.std(data, axis=0)

    # Apply normalization
    normalized_data = (data - mean) / std
    normalized_data = np.expand_dims(normalized_data, axis=-1)

    return normalized_data


def train(x_train, learning_rate, batch_size, epochs):
    autoencoder = Autoencoder(
        input_shape=(599, 128, 5),
        conv_filters=(16, 32, 32),
        conv_kernels=(4, 4, 4),
        conv_strides=(2, 2, 2),
        latent_space_dim=6144
    )
    autoencoder.summary()

    autoencoder.compile(learning_rate)
    # Implement early stopping
    early_stopping = EarlyStopping(monitor='loss', patience=5, restore_best_weights=True)

    autoencoder.train(x_train, batch_size, epochs, callbacks=[early_stopping])
    return autoencoder


if __name__ == "__main__":
    train_size = 1000
    # Load data
    data = []

    with open("data.pkl", 'rb') as f:
        content = f.read()
        data = pickle.loads(content)
    # Convert data to NumPy array
    data = np.asarray(data)
    permutation = np.random.permutation(len(data))
    data = data[permutation]
    normalized_data = normalize_data(data)
    trainData = normalized_data[:train_size]
    x_train = trainData


    autoencoder = train(x_train, LEARNING_RATE, BATCH_SIZE, EPOCHS)
    autoencoder.save("model")